#pragma once
#include "player.h"
#include <stdlib.h>
#include <stdbool.h>

//Estructura del Equipo
typedef struct
{
    char* name;
    int max_members;
    Player* members;   
}Team;

void team_init(Team* team, char* name, int max_members);

void print_team_info(Team team);

void set_team_name(Team* team, char* name);

void team_fight(Team* team_red, Team* team_blue);

bool team_can_continue(Team team);

Team* winner(Team* red, Team* blue);
