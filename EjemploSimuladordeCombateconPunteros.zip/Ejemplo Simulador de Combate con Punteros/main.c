#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "team.c"
#include "player.c"

int main()
{
    srand(time(NULL));

    //m -> cantidad de equipos; n -> cantidad de jugadores por equipo
    int m = 2, n = 4;
    int turns = 1;

    //Se crea un arreglo de equipos
    Team team[m];

    do
    {
        printf("Indique cuantos turnos durara la partida: ");
        scanf("%d", &turns);
    }while(turns < 1);
    
    for(int i = 0; i < m; i++)
    {
        char name[50];
        sprintf(name, "%d", i + 1);

        //Inicializa a cada equipo en el arreglo
        /*Se utiliza el operador & para poder acceder a la referencia de memoria,
        puesto que la función team_init requiere un puntero del tipo Team.
        Para que se visualice mejor también se podría hacer:
            Team* ptr = &team[i];
            team_init(ptr, name, n);
        Ambos casos son equivalentes tanto el código comentado como el implementado
        */
        team_init(&team[i], name, n);

        for(int j = 0; j < n; j++)
        {
            sprintf(name, "Moai %d", j + 1);

            /*La misma lógica vista con anterioridad para el jugador.
            De igual forma, para que se visualice mejor también se podría hacer:
                Player* ptr = &team[i].members[j];
                player_init(ptr, name,
                rand()%100 + 1, rand()%100 + 1, rand()%100 + 1);
            Ambos casos son equivalentes tanto el código comentado como el implementado
            */
            player_init(&team[i].members[j], name,
            rand()%100 + 1, rand()%100 + 1, rand()%100 + 1);
        }

        print_team_info(team[i]);
    }

    /*Se realizo el set y luego el print para demostrar que los cambios persistentes luego de haber 
        salido de las funciones */

    set_team_name(&team[0], "Aguilas Negras");
    set_team_name(&team[1], "Leones Azules");

    set_player_name(&team[0].members[0], "Edelgard");
    set_player_name(&team[0].members[1], "Bernadetta");
    set_player_name(&team[0].members[2], "Dorothea");
    set_player_name(&team[0].members[3], "Lysithea");

    set_player_name(&team[1].members[0], "Dimitri");
    set_player_name(&team[1].members[1], "Dedue");
    set_player_name(&team[1].members[2], "Sylvain");
    set_player_name(&team[1].members[3], "Ingrid");

    print_team_info(team[0]);
    print_team_info(team[1]);

    for(int i = 0; i < turns; i++)
    {
        char turn[10];
        sprintf(turn, "Turno %d", i + 1);
        printf("%s\n", turn);

        team_fight(&team[0], &team[1]);

        //Si uno de los equipos se queda sin miembros se rompe el bucle
        if(!team_can_continue(team[0]) || !team_can_continue(team[1]))
            break;
    }

    //Se dictamina al ganador
    winner(&team[0], &team[1]);

    return 0;
}