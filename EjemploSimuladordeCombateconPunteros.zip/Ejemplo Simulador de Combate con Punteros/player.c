#include <stdio.h>
#include "player.h"
#include <string.h>



//Inicializador de un Jugador (Sólo para variables tipo Player recién declaradas)
//\El inicializador va asignandole valores a todas las variables de la estructura con los parámetros dados
void player_init(Player* player, char* name, int health, int strength, int defense)
{
    //Se obtiene el tamaño del parámetro name que es una string que se asigna a un puntero
    int max = strlen(name);

    //Declaración de arreglo de caracteres por medio de un puntero en este caso el atributo name que es un puntero de tipo char
    /*El malloc se usa para asignar la memoria correspondiente junto con el operador sizeof y se multiplica con la variable max,
    puesto que queremos que el nombre del jugador tenga el mismo tamaño que la cadena externa*/
    player->name = malloc(max*sizeof(char));

    for(int i = 0; i < max; i++)
        player->name[i] = name[i]; 

    player->health = health;
    player->strength = strength;
    player->defense = defense;
    player->exp = 0;
}


//Imprime los datos del jugador
void print_player_info(Player player)
{
    print_player_info_align(player, "");
}

//Align sólo es por cuestiones de estética

//Imprime los datos del jugador con un patrón al inicio de cada línea
void print_player_info_align(Player player, char* align)
{
    printf("%sDatos de %s\n", align, player.name);
    printf("%s\033[0;35mSalud: \033[0;34m%d \n", align, player.health);
    printf("%s\033[0;35mFuerza: \033[0;34m%d \n", align, player.strength);
    printf("%s\033[0;35mDefensa: \033[0;34m%d\n", align, player.defense);
    printf("%s\033[0;35mExperiencia: \033[0;34m%d\033[0m\n\n", align, player.exp);
}


/*Al modificar un jugador se utiliza el puntero para acceder a la variable guardada en esa dirección de memoria 
ya que queremos que este cambio se mantenga más allá de la existencia interna de la funciones set*/

//Modifica el nombre del jugador
void set_player_name(Player* player, char* name)
{
    /*Cuando se utiliza malloc es obligatorio estar pendiente de llamar a la función free cuando vayamos a modificar
    por completo el puntero, de no hacerlo esa memoria seguirá siendo ocupada, pero ya no podremos acceder a ella*/
    free(player->name);
    int max = strlen(name);
    player->name = malloc(max*sizeof(char));
    for(int i = 0; i < max; i++)
        player->name[i] = name[i];
}

//Modifica la estadística del jugador indicada por medio de su nombre
void set_player_stat(Player* player, enum StatName stat, int value)
{
    switch(stat)
    {
        case Health: player->health = value; break;
        case Strength: player->strength = value; break;
        case Defense: player->defense = value; break;
        case EXP: player->exp = value; break;
        default: printf("Asignacion invalida"); break;
    }
}

/*Aquí por su parte no resulta necesario utilizar un puntero, pues sólo buscamos obtener información externa
para poder realizar el cálculo de la fórmula*/

//Calcula el daño infligido que realiza el segundo jugador al primero
int player_dealt_damage(Player attacked, Player attacker)
{
    int dmg = attacker.strength - attacked.defense/2;

    if(dmg < 0)
        return 0;

    return dmg;
}

/*Aquí nuevamente requerimos de un puntero, pues si un jugador derrota a otro incrementa sus puntos de experiencia
y resulta necesario que ese cambio sea fijo*/

/*Simula la pelea entre dos jugadores (Red vs. Blue), retorna verdadero si un jugador derrota a otro y
falso si ambos pueden continuar*/
bool player_fight(Player* red, Player* blue)
{
    printf("\033[0;35mSe enfrenta %s contra %s\n", red->name, blue->name);

    /*Aquí aplicamos el operador * al puntero para desreferenciar la dirección de memoria,
    ya que la función anterior no utiliza punteros, en otras palabras:
    la variable Player* (Puntero) con operador * pasa a ser sólo Player (No puntero) */
    int dmg = player_dealt_damage(*red, *blue);

    printf("\033[0mEs el turno de %s...\n", blue->name);
    set_player_stat(red, Health, red->health - dmg);

    printf("\033[0;36m%s ha recibido %d de dmg", red->name, dmg);
    if(red->health <= 0)
    {   
        set_player_stat(blue, EXP, blue->exp + 25);
        printf("\033[0m\nHa sido derrotado, %s gana %d de EXP\n\n", blue->name, 25);
        return true; 
    }

    printf("\033[0m\n\n");
            
    return false;
}
