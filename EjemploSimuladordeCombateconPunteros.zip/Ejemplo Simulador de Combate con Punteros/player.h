#pragma once
#include <stdbool.h>


enum StatName{Health, Strength, Defense, EXP};

//Estructura del jugador 
typedef struct
{
    char* name;
    int health;
    int strength;
    int defense;
    int exp;
}Player;

void player_init(Player* player, char* name, 
    int health, int strength, int defense);

void print_player_info(Player player);

void print_player_info_align(Player player, char* align);

void set_player_name(Player* player, char* name);

void set_player_stat(Player* player, enum StatName stat, int value);

int player_dealt_damage(Player attacker, Player attacked);

bool player_fight(Player* red, Player* blue);