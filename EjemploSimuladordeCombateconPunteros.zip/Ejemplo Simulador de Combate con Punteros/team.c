#include "team.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>

//Inicializa un Equipo (Sólo para variables tipo Team recién declaradas)
//\Notar que el iniciador recibe la cantidad de integrantes que posee
void team_init(Team* team, char* name, int max_members)
{
    int max = strlen(name);
    team->name = malloc(max*sizeof(char));
    for(int i = 0; i < max; i++)
        team->name[i] = name[i];
    team->max_members = abs(max_members);
    team->members = malloc(team->max_members*sizeof(Player));
}

//Imprime la información del equipo incluido sus integrantes
void print_team_info(Team team)
{
    printf("Equipo: %s\n", team.name);
    for(int i = 0; i < team.max_members; i++)
        print_player_info_align(team.members[i], "\t");
}

//Modifica el nombre del equipo
void set_team_name(Team* team, char* name)
{
    free(team->name);
    int max = strlen(name);
    team->name = malloc(max*sizeof(char));
    for(int i = 0; i < max; i++)
        team->name[i] = name[i];
}

//Inicia un pelea en equipo seleccionando al azar un miembro de cada uno (Red vs. Blue)
void team_fight(Team* team_red, Team* team_blue)
{   
    int rand_red = 0, rand_blue = 0;
    bool is_first = true;

    Player* player_red = &team_red->members[rand_red];
    Player* player_blue = &team_blue->members[rand_blue];

    do
    {
        if(is_first || player_red->health <= 0)
            rand_red = rand()%team_red->max_members;
        
        if(is_first || player_blue->health <= 0)
            rand_blue = rand()%team_blue->max_members;
        is_first = false;
        player_red = &team_red->members[rand_red];
        player_blue = &team_blue->members[rand_blue];
    }while(player_red->health <= 0 || player_blue->health <= 0);

    int first = rand()%2;

    if(first == 0)
    {
        printf("Empieza equipo: %s\n", team_red->name);
        if(player_fight(player_red, player_blue))
            return;
        printf("Le toca al equipo: %s\n", team_blue->name);
        player_fight(player_blue, player_red);
    }
    else
    {
        printf("Empieza equipo: %s\n", team_blue->name);
        if(player_fight(player_blue, player_red))
            return;
        printf("Le toca al equipo: %s\n", team_red->name);
        player_fight(player_red, player_red);
    }
}

//Retorna verdadero si el equipo tiene al menos un integrante con salud sobre 0 de no ser así retorna falso
bool team_can_continue(Team team)
{
    for(int i = 0; i < team.max_members; i++)
    {
        if(team.members[i].health > 0)
            return true;
    }

    return false;
}

//Determina entre dos equipos el ganador, retornandolo, de haber empate retorna NULL
Team* winner(Team* red, Team* blue)
{
    int total_exp_red = 0, total_exp_blue = 0;

    for(int i = 0; i < red->max_members; i++)
        total_exp_red += red->members[i].exp;
    for(int i = 0; i < blue->max_members; i++)
        total_exp_blue += blue->members[i].exp;


    if(!team_can_continue(*red) && !team_can_continue(*blue))
    {
        printf("\033[0;31mAmbos equipos se quedaron sin miembros\nHa sido un empate\033[0m\n");
        return NULL;
    }
    if(!team_can_continue(*red))
    {
        printf("\033[0;32mGana el equipo %s, pues el equipo %s no puede continuar\033[0m\n", blue->name, red->name);
        return blue;
    }

    if(!team_can_continue(*blue))
    {
        printf("\033[0;32mGana el equipo %s, pues el equipo %s no puede continuar\033[0m\n", red->name, blue->name);
        return blue;
    }
    
    if(total_exp_blue > total_exp_red)
    {
        printf("\033[0;32mGana el equipo %s con %d puntos sobre los %d puntos del equipo rival\033[0m\n", 
            blue->name, total_exp_blue, total_exp_red);
        return blue;
    }
    
    if(total_exp_blue < total_exp_red)
    {
        printf("\033[0;32mGana el equipo %s con %d puntos sobre los %d puntos del equipo rival\033[0m\n", 
            red->name, total_exp_red, total_exp_blue);
        return red;
    }

    printf("\033[0;31mHa sido un empate ambos con %d puntos\033[0m\n", total_exp_blue);
    return NULL;
}